package com.ProductMain;
import java.util.ArrayList;
import java.util.Scanner;
import com.ProductController.Controller;
import com.ProductEntity.Product;
public class ProductMain {

	public static void main(String[] args) {
		Controller controller = new Controller();
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("\n\nEnter Your Choice");
			System.out.println("1. insert product ");
			System.out.println("2. update product ");
			System.out.println("3. get product by id");
			System.out.println("4. get all products");
			System.out.println("5. delete prduct");
			System.out.println("6. Exit");

			int choice = sc.nextInt();
			switch (choice) {
			case 1:

				System.out.println("Enter Product Id");
				int id = sc.nextInt();
				System.out.println("Enter Product Name");
				String name = sc.next();
				System.out.println("Enter company Name");
				String company = sc.next();
				System.out.println("Enter Product Price");
				double price = sc.nextDouble();

				Product p1 = new Product(id, name, company, price);
				String msg = controller.insertData(p1);
				System.out.println(msg);
				break;
			case 2:
				System.out.println("Enter Product Id");
				int idd = sc.nextInt();
				System.out.println("Enter Product Name");
				String namee = sc.next();
				System.out.println("Enter company Name");
				String companyy = sc.next();
				System.out.println("Enter Product Price");
				double pricee = sc.nextDouble();
				Product pp = new Product(idd, namee, companyy, pricee);

				String msgg = controller.updateData(pp);
				System.out.println(msgg);
				break;
					
			case 3:
				System.out.println("enter the id you want to get product");
				int i = sc.nextInt();
				ArrayList<Product> pro = controller.getById(i);
				pro.stream().forEach(p -> {
					System.out.println("Product Id      -->  " + p.getProductId());
					System.out.println("Product Name    -->  " + p.getProductName());
					System.out.println("Product Company -->  " + p.getCompany());
					System.out.println("Product Price   -->  " + p.getPrice());
					System.out.println("====================================");
				});
				break;
					
			case 4:
				ArrayList<Product> prod = controller.getAllData();
				prod.stream().forEach(p -> {
					System.out.println("Product Id      -->  " + p.getProductId());
					System.out.println("Product Name    -->  " + p.getProductName());
					System.out.println("Product Company -->  " + p.getCompany());
					System.out.println("Product Price   -->  " + p.getPrice());
					System.out.println("====================================");

				});
				break;
					
			case 5:
				System.out.println("enter product id you want to delete");
				int iddd = sc.nextInt();
				String ms = controller.deleteProduct(iddd);
				System.out.println(ms);
				break;
					
			case 6:
				System.out.println("Thank You For Use My Application");
				return;

			}

		}

	}

}
