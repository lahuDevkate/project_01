package com.ProductDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ProductEntity.Product;
import com.jdbcConnection.JDBCUtil;

public class ProductDao {

	Connection conn = JDBCUtil.getConnection();

	public String createTable() {
		try {
			Statement st = conn.createStatement();
			int r = st.executeUpdate(
					"create table products (id int , productname varchar(10) , company varchar(20) , price double)");

			if (r > 0)
				return "Table created ";

		} catch (Exception e) {
			e.getMessage();
		}

		return null;
	}

	public String insertData(Product pdt) {
		try {

			PreparedStatement pst = conn.prepareStatement("insert into products values (?,?,?,?)");
			pst.setInt(1, pdt.getProductId());
			pst.setString(2, pdt.getProductName());
			pst.setString(3, pdt.getCompany());
			pst.setDouble(4, pdt.getPrice());

			int re = pst.executeUpdate();

			if (re > 0)
				return "Data Inserted";

		} catch (Exception e) {
			e.getMessage();
		}

		return null;

	}

	public String updateData(Product product) {
		try {
			PreparedStatement pst = conn
					.prepareStatement("update products set productname=?, company=? , price=?  where id=?");
			pst.setString(1, product.getProductName());
			pst.setString(2, product.getCompany());
			pst.setDouble(3, product.getPrice());
			pst.setInt(4, product.getProductId());

			int re = pst.executeUpdate();
			if (re > 0)
				return "Data Updated";

		} catch (Exception e) {
			e.getMessage();
		}
		return null;

	}

	public ArrayList<Product> getById(int id) {
		ArrayList<Product> product = new ArrayList<>();
		try {
			PreparedStatement pst = conn.prepareStatement("select * from products where id=?");
			pst.setInt(1, id);

			ResultSet result = pst.executeQuery();

			while (result.next()) {
				int pId = result.getInt("id");
				String pName = result.getString("productname");
				String company = result.getString("company");
				double price = result.getDouble("price");
				Product pro = new Product(pId, pName, company, price);
				product.add(pro);

			}

		} catch (Exception e) {
			e.getMessage();
		}

		return product;
	}

	public ArrayList<Product> getAllProducts() {

		ArrayList<Product> product = new ArrayList<>();

		try {
			PreparedStatement pst = conn.prepareStatement("select * from products");
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String productName = rs.getString("productname");
				String company = rs.getString("company");
				double price = rs.getDouble("price");

				Product pro = new Product(id, productName, company, price);
				product.add(pro);
			}

		} catch (Exception e) {
			e.getMessage();
		}

		return product;
	}

	public String deleteProduct(int id) {

		try {
			PreparedStatement pst = conn.prepareStatement("delete from  products where id=?");
			pst.setInt(1, id);

			int result = pst.executeUpdate();
			if (result > 0)
				return "Product Deleted ......";

		} catch (Exception e) {
			e.getMessage();
		}

		return null;
	}

}
