package com.ProductController;

import java.util.ArrayList;

import com.ProductEntity.Product;
import com.ProductService.Service;

public class Controller {
	
	Service service =  new Service();
	
	public String  insertData(Product product)
	{
		return service.insertData(product);
	}
	
	public String  updateData(Product product)
	{
		return service.updateData(product);
	}
	
	public String deleteProduct(int id)
	{
		return service.deleteData(id);
	}
	
	public ArrayList<Product> getById(int id)
	{
		return service.getById(id);
	}
	
	public ArrayList<Product> getAllData()
	{
		return service.getAllProducts();
	}

}
