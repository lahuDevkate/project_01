package com.ProductEntity;

public class Product {
	
	private int productId;
	private String productName;
	private String company;
	private double price;
	
	
	
	public Product()
	{
		
	}

	public Product(int productId, String productName, String company, double price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.company = company;
		this.price = price;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	

	
	
	

}
