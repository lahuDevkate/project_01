package com.jdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCUtil {

	private static String url = "jdbc:mysql://localhost:3306/productdb";
	private static String userName = "root";
	private static String passwd = "Sonu@123";

	public static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			conn = DriverManager.getConnection(url, userName, passwd);

		} catch (Exception e) {
			e.getMessage();
		}

		return conn;
	}

}
