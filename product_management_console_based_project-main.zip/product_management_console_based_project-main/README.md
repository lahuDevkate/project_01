# Product Management System

This project is a simple Java console application for managing products using the MySQL database. It follows a basic MVC-style structure with separate layers for controller, service, DAO, entity, and database connectivity.

## Project Overview

The application allows users to:

- Insert a new product
- Update an existing product
- Get product details by product ID
- Get all products
- Delete a product
- Exit the application

It is built as a menu-driven console app and is primarily intended for learning Java database connectivity and layered application design.

## Tech Stack

- Java
- MySQL
- JDBC
- Console-based user interface

## Project Structure

```text
project/
├── jdbcConnection/
│   └── JDBCUtil.java
├── ProductController/
│   └── Controller.java
├── ProductDao/
│   └── ProductDao.java
├── ProductEntity/
│   └── Product.java
├── ProductMain/
│   └── ProductMain.java
├── ProductService/
│   └── Service.java
└── README.md
```

## Package Details

### 1. ProductMain
Contains the main menu logic and the program entry point.

- File: `ProductMain.java`
- Responsible for:
  - taking user input
  - calling controller methods
  - displaying product information

### 2. ProductController
Acts as the interface layer between the UI and the service layer.

- File: `Controller.java`
- Methods:
  - `insertData(Product product)`
  - `updateData(Product product)`
  - `deleteProduct(int id)`
  - `getById(int id)`
  - `getAllData()`

### 3. ProductService
Contains the business logic and delegates calls to the DAO layer.

- File: `Service.java`
- Used to validate and forward data operations to the database layer.

### 4. ProductDao
Performs all database CRUD operations using JDBC.

- File: `ProductDao.java`
- Contains SQL queries for:
  - insert
  - update
  - fetch by id
  - fetch all
  - delete

### 5. ProductEntity
Defines the `Product` model object.

- File: `Product.java`
- Fields:
  - `productId`
  - `productName`
  - `company`
  - `price`

### 6. jdbcConnection
Handles MySQL connection configuration.

- File: `JDBCUtil.java`
- Establishes the JDBC connection using `DriverManager.getConnection()`.

## Database Configuration

The application currently connects to a MySQL database using the following setup in `JDBCUtil.java`:

```java
private static String url = "jdbc:mysql://localhost:3306/productdb";
private static String userName = "root";
private static String passwd = "Sonu@123";
```

Before running the app, make sure:

1. MySQL is installed and running.
2. A database named `productdb` exists.
3. The MySQL user credentials are valid.
4. The MySQL JDBC driver is available in the project classpath.

## Database Table

The application uses a table named `products`.

```sql
create table products (
    id int,
    productname varchar(10),
    company varchar(20),
    price double
);
```

## Application Menu

When the program runs, it displays a menu like this:

```text
Enter Your Choice
1. insert product
2. update product
3. get product by id
4. get all products
5. delete product
6. Exit
```

## How to Run

1. Open the project in your Java IDE or terminal.
2. Ensure MySQL is running.
3. Add the MySQL connector JAR to the classpath.
4. Compile the Java files.
5. Run the `ProductMain` class.

## Example Workflow

### Insert Product
- Enter product ID
- Enter product name
- Enter company name
- Enter price

### Update Product
- Enter the product ID to update
- Provide new product name, company, and price

### Get Product By ID
- Enter the product ID
- The program prints the matching product details

### Get All Products
- Displays all entries stored in the `products` table

### Delete Product
- Enter the product ID to remove

## Notes

This project is a beginner-friendly database application that demonstrates:

- layered architecture
- JDBC implementation
- console-based design
- CRUD operations in Java

## Future Improvements

- Add validation for invalid user inputs
- Use proper exception handling and logging
- Support product name lengths greater than 10 chars
- Add user-friendly messages for failed database operations
- Use a GUI or web frontend

## Conclusion

This project is a basic Java product management system built with MySQL and JDBC. It is suitable for learning database integration, Java classes, and layered design in a small application.
