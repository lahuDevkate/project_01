package com.ProductService;

import java.util.ArrayList;

import com.ProductDao.ProductDao;
import com.ProductEntity.Product;

public class Service {
	
	public Service()
	{
		
	}
	
	ProductDao dao = new ProductDao();
	
	public String insertData(Product product)
	{
		return dao.insertData(product);
	}
	
	public String updateData(Product product)
	{
		return dao.updateData(product);
	}
	
	public String deleteData(int id)
	{
		return dao.deleteProduct(id);
	}
	
	
	public ArrayList<Product> getById(int id)
	{
		ArrayList<Product> pro = dao.getById(id);
		
		return pro;
	}
	
	public ArrayList<Product> getAllProducts()
	{
		ArrayList<Product> pro =dao.getAllProducts();
		
		return pro;
	}
	
	
	
	
}
